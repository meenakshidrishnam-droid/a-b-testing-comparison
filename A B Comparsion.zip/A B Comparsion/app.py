import streamlit as st
import pandas as pd

# Page Title
st.set_page_config(page_title="Student Dataset Dashboard", layout="wide")

st.title("📊 Student Dataset Dashboard")

# Load CSV
df = pd.read_csv("students.csv")

# Display Dataset
st.subheader("Dataset")
st.dataframe(df, use_container_width=True)

# Basic Statistics
st.subheader("Summary Statistics")
st.write(df.describe())

# Search by Name
st.subheader("Search Student")
search_name = st.text_input("Enter Name")

if search_name:
    result = df[df["Name"].str.contains(search_name, case=False)]
    st.dataframe(result)

# Filter by City
st.subheader("Filter by City")
city = st.selectbox("Select City", ["All"] + list(df["City"].unique()))

if city != "All":
    filtered_df = df[df["City"] == city]
else:
    filtered_df = df

st.dataframe(filtered_df)

# Age Chart
st.subheader("Age Distribution")
st.bar_chart(df.set_index("Name")["Age"])

# Metrics
st.subheader("Quick Metrics")
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Students", len(df))

with col2:
    st.metric("Average Age", round(df["Age"].mean(), 1))

with col3:
    st.metric("Cities", df["City"].nunique())

# Download Data
st.subheader("Download Dataset")
csv = df.to_csv(index=False).encode("utf-8")

st.download_button(
    label="Download CSV",
    data=csv,
    file_name="students.csv",
    mime="text/csv"
)